#########################
# 무한의 탑 데이터 입력 #
#########################

INSERT INTO `chara_cards` VALUES (90001,'달빛공주 레미아','- TheMoon - Lamia',10,16,14,12,10,35,346112,'standmon025_00','mc025_00.swf','','','달의 대륙을 지배하는 흡혈 공주의 진정한 모습. 달의 모든 것을 만들었다고 한다.',2001,0,'2010-07-16 15:24:13',NULL,6,'Lady Lamia of Moonlight','- TheMoon -','Ruler and creator of Moonland.','月光姫レミア','- TheMoon - Lamia','月大陸を制する吸血姫の真の姿。月大陸の全てを作り出したといわれる。','月光姬蕾米雅','- TheMoon - Lamia','統治月大陸的吸血姬真正姿態。據說是她創造了整個月大陸。','Lamia','Lamia','Créateur et Souverain de MoonLand.','Lamia','- TheMoon - Lamia','Pencipta sekaligus penguasa MoonLand.','องค์หญิงจันทรา เลเมีย','- TheMoon - Lamia','ร่างจริงของเจ้าหญิงผีดูดเลือด ผู้ปกครองแดนจันทรา\r','달빛공주 레미아','- TheMoon - Lamia','달의 대륙을 지배하는 흡혈 공주의 진정한 모습. 달의 모든 것을 만들었다고 한다.');
INSERT INTO `chara_cards` VALUES (90002,'우보스','- LakeKeeper - Ubos',10,22,12,4,10,40,334422,'standmon030_00','mc030_00.swf','','','검게 물든 호수를 침식하는 거대 그림자.',2002,0,'2010-07-16 15:24:13',NULL,6,'Ubos','- LakeKeeper -','A humongous shadow beneath the waters of an inky black lake.','ウボス','- LakeKeeper - Ubos','黑く染まった湖を侵食する巨大な影。','烏波斯','- LakeKeeper - Ubos','侵蝕著染黑湖泊的巨大黑影。','Ubos','Ubos','Roi du Lac d\'Obscurité.','Ubos','- LakeKeeper - Ubos','Penguasa Danau Kegelapan.','ยามเฝ้าประตู อูโบส','- LakeKeeper - Ubos','เงายักษ์ที่เข้าลุกล้ำทะเลสาบสีดำ\r','우보스','- LakeKeeper - Ubos','검게 물든 호수를 침식하는 거대 그림자.');
INSERT INTO `chara_cards` VALUES (90003,'비룡왕 메류지누','- EmptyKing - Melusine',10,24,16,10,10,45,771273,'standmon037_00','mc037_00.swf','','','바람의 나라를 다스리는 하늘의 왕자.',2003,0,'2010-07-16 15:24:13',NULL,6,'Melusine','- EmptyKing -','King of the Land of Wind and ruler of the skies.','飛竜王メリュジーヌ','- EmptyKing - Melusine','風の国を治める空の王者。','飛龍王梅爾基努','- EmptyKing - Melusine','統治風之國的空之王者。','Mélusine','Mélusine','Souverain du WindLand et Roi du Ciel.','Melusine','- DragonLord - Melusine','Raja angkasa & penguasa WindLand.','ราชามังกร เมลูซีน','- EmptyKing - Melusine','ราชาแห่งความว่างเปล่า ผู้ปกครองนครวายุ\r','비룡왕 메류지누','- EmptyKing - Melusine','바람의 나라를 다스리는 하늘의 왕자.');
INSERT INTO `chara_cards` VALUES (90007,'수호자 아스타로스','- Ark Guardian - Astaroth',10,22,12,14,10,40,636212,'standmon044_00','mc044_00.swf','','','악마의 충실한 부하. 성궤의 복제품을 만들어 내어 세계를 암흑으로 인도한다.',2007,0,'2010-07-16 15:24:13',NULL,6,'Astaroth','- Ark Guardian -','The dilligent subordinate of an evil god. Intends to bring the world into darkness by creating assorted perverted replicas of the Ark of the Coventant. ','守護者アスタロト','- Ark Guardian - Astaroth','悪神の忠実なる手下。聖櫃の複製品を次々と作り出し、世界を闇に堕とす。','守護者亞斯塔祿','- Ark Guardian - Astaroth','惡神忠心的手下。接二連三的製作聖櫃複製品，企圖讓世界墜落於黑暗。','Astaroth','- Gardien de l\'Arche -','Fidèle du Diable, il crée des Tabernacles à la chaîne et fait sombrer le Monde dans les Ténèbres.','Astaroth','- Ark Guardian - Astaroth','Pelayan setia Iblis. Menciptakan serangkaian Tabernakel dan menenggelamkan dunia dalam kegelapan.','ผู้ปกป้อง แอสทาร็อธ','- Ark Guardian - Astaroth','สมุนผู้ซื่อสัตย์ของซาตาน จำลองแท่นบูชาปลอมขึ้นมาเพื่อให้โลกตกอยู่ในความมืด\r','수호자 아스타로스','- Ark Guardian - Astaroth','악마의 충실한 부하. 성궤의 복제품을 만들어 내어 세계를 암흑으로 인도한다.');
INSERT INTO `chara_cards` VALUES (90008,'얼음악마 브렌단','- Ice Demon - Brendan',10,25,17,13,10,45,236123,'standmon048_00','mc048_00.swf','','','다른 세계에서 추방된 아름다운 남성의 악마. 원망에 의해 얼어붙은 불꽃을 사용한다.',2008,0,'2010-07-16 15:24:13',NULL,6,'Brendan','- Ice Demon -','A beautiful masculine daemon banished from another realm. Commands frozen flames of resentment.','氷魔ブレンダン','- Ice Demon - Brendan','別の世界で追放された美しき男性の悪魔。怨嗟によって凍てついた炎を駆使する。','冰魔布蘭登','- Ice Demon - Brendan','被別的世界放逐的美型男惡魔。驅使因怨恨而凍結的火炎。','Brendan','- Démon des Glaces -','Démon d\'un Ephèbe exilé de l\'autre Monde. Il a la maîtrise d\'un feu glacé.','Brendan','- Ice Demon - Brendan','Iblis yang diasingkan dari dunia lain. Dapat mengendalikan api dingin.','ปิศาจน้ำแข็ง เบรนดัน','- Ice Demon - Brendan','ปิศาจเพศชายผู้งดงามที่ถูกขับไล่ออกจากต่างโลก สามารถใช้เพลิงน้ำแข็งได้รุนแรงตามความแค้นในใจ\r','얼음악마 브렌단','- Ice Demon - Brendan','다른 세계에서 추방된 아름다운 남성의 악마. 원망에 의해 얼어붙은 불꽃을 사용한다.');
INSERT INTO `chara_cards` VALUES (90016,'성역의 개선문','- Heaven\'s door - Gate of Sanctuary',10,50,15,25,10,50,222555,'standmon061_00','mc061_00.swf','','','불의 성역을 지키는 과거의 기계문. 모든 방호기능을 갖추고 있다.',2016,0,'2010-07-16 15:24:13',NULL,6,'Heaven\'s Sacred Arches','- Heaven\'s door -','The mechanical gates protecting the sanctuary of flame. Equipped with functions providing protection from everything.','聖域の凱旋門','- Heaven\'s door - Gate of Sanctuary','炎の聖域を守るいにしえの機械門。あらゆる防護機能を備えている。','聖域的凱旋門','- Heaven\'s door - Gate of Sanctuary','守護著炎之聖域的古老機械門。備有萬無一失的防衛機能。','Arche Sacrée','- la porte de la paradie -','Portes mécaniques qui protègent le sanctuaire de la Flamme. Elles disposent de tous les dispositifs de sécurité.','Sanctuary Arc','- Heaven\'s door - Gate of Sanctuary','Pintu mekanis untuk melindungi Kuil Api. Memiliki berbagai alat perlindungan diri.','ประตูชัยแห่งแดนศักดิ์สิทธิ์','- Heaven\'s door - Gate of Sanctuary','ประตูกลโบราณที่ป้องกันปราสาทศักดิ์สิทธิ์แห่งเพลิง ติดตั้งเครื่องป้องกันทุกอย่างที่มี\r','성역의 개선문','- Heaven\'s door - Gate of Sanctuary','불의 성역을 지키는 과거의 기계문. 모든 방호기능을 갖추고 있다.');

INSERT INTO `cpu_card_datas` VALUES (99991,'monster','90001','0','0','36/36/44/44/61/62/36/36/44/44/61/62/36/36/44/44/61/62',NULL,'2014-06-19 05:50:41','2014-06-19 08:03:32','monster','무한의탑','monster','monster','monster','monster','monster',20);
INSERT INTO `cpu_card_datas` VALUES (99992,'monster','90002','0','0','36/36/44/44/61/62/36/36/44/44/61/62/36/36/44/44/61/62',NULL,'2014-06-19 05:52:00','2014-06-19 08:03:40','monster','무한의탑','monster','monster','monster','monster','monster',20);
INSERT INTO `cpu_card_datas` VALUES (99993,'monster','90003','0','0','36/36/44/44/61/62/36/36/44/44/61/62/36/36/44/44/61/62',NULL,'2014-06-19 05:53:36','2014-06-19 08:03:48','monster','무한의탑','monster','monster','monster','monster','monster',20);
INSERT INTO `cpu_card_datas` VALUES (99994,'monster','90007','0','0','36/36/44/44/61/62/36/36/44/44/61/62/36/36/44/44/61/62',NULL,'2014-06-19 05:54:40','2014-06-19 08:03:06','monster','무한의탑','monster','monster','monster','monster','monster',20);
INSERT INTO `cpu_card_datas` VALUES (99995,'monster','90008','0','0','36/36/44/44/61/62/36/36/44/44/61/62/36/36/44/44/61/62',NULL,'2014-06-19 05:56:23','2014-06-19 08:03:13','monster','무한의탑','monster','monster','monster','monster','monster',20);
INSERT INTO `cpu_card_datas` VALUES (99996,'monster','90016','0','0','36/36/44/44/61/62/36/36/44/44/61/62/36/36/44/44/61/62',NULL,'2014-06-19 05:57:34','2014-06-19 08:03:20','monster','무한의탑','monster','monster','monster','monster','monster',20);

INSERT INTO `feat_inventories` VALUES (90011,90001,201,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90012,90001,202,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90013,90001,203,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90014,90001,204,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90021,90002,302,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90022,90002,303,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90023,90002,304,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90024,90002,305,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90031,90003,351,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90032,90003,352,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90033,90003,353,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90034,90003,354,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90041,90007,530,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90042,90007,531,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90043,90007,532,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90044,90007,533,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90051,90008,534,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90052,90008,535,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90053,90008,536,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90054,90008,537,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90061,90016,720,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90062,90016,721,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90063,90016,722,NULL,NULL);
INSERT INTO `feat_inventories` VALUES (90064,90016,723,NULL,NULL);

INSERT INTO `passive_skill_inventories` VALUES (90001,90001,20,NULL,NULL);
INSERT INTO `passive_skill_inventories` VALUES (90002,90002,20,NULL,NULL);
INSERT INTO `passive_skill_inventories` VALUES (90003,90003,20,NULL,NULL);
INSERT INTO `passive_skill_inventories` VALUES (90007,90007,20,NULL,NULL);
INSERT INTO `passive_skill_inventories` VALUES (90008,90008,20,NULL,NULL);
INSERT INTO `passive_skill_inventories` VALUES (90016,90016,20,NULL,NULL);

INSERT INTO `quest_maps` VALUES (991,'','',0,99,99,99,NULL,NULL,'','','무한의탑','당신의 능력을 시험해보세요!','','','','','무한의탑','당신의 능력을 시험해보세요!','','','','\r');

INSERT INTO `quest_lands` VALUES (99991,'',99991,69001,1,0,'',NULL,'2014-06-19 08:01:30','','','무한의탑','',NULL,NULL,'','','무한의탑','','','','','');
INSERT INTO `quest_lands` VALUES (99992,'',99992,69002,1,0,'',NULL,'2014-06-19 08:01:46','','','무한의탑','',NULL,NULL,'','','무한의탑','','','','','');
INSERT INTO `quest_lands` VALUES (99993,'',99993,69003,1,0,'',NULL,'2014-06-19 08:01:37','','','무한의탑','',NULL,NULL,'','','무한의탑','','','','','');
INSERT INTO `quest_lands` VALUES (99994,'',99994,69004,1,0,'',NULL,'2014-06-19 08:01:54','','','무한의탑','',NULL,NULL,'','','무한의탑','','','','','');
INSERT INTO `quest_lands` VALUES (99995,'',99995,69005,1,0,'',NULL,'2014-06-19 08:02:02','','','무한의탑','',NULL,NULL,'','','무한의탑','','','','','');
INSERT INTO `quest_lands` VALUES (99996,'',99996,69006,1,0,'',NULL,'2014-06-19 08:01:20','','','무한의탑','',NULL,NULL,'','','무한의탑','','','','','');

INSERT INTO `quests` VALUES (99991,991,'','',1,0,0,4,0,0,99991,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,'2014-06-19 08:09:17','No pair',NULL,'무한의탑','당신의 능력을 시험해보세요!','','','','','무한의탑','당신의 능력을 시험해보세요!','','','','\r',0);
INSERT INTO `quests` VALUES (99992,991,'','',1,0,0,5,0,0,99992,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,'2014-06-19 08:09:17','No pair',NULL,'무한의탑','당신의 능력을 시험해보세요!','','','','','무한의탑','당신의 능력을 시험해보세요!','','','','\r',0);
INSERT INTO `quests` VALUES (99993,991,'','',1,0,0,1,0,0,99993,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,'2014-06-19 08:09:17','No pair',NULL,'무한의탑','당신의 능력을 시험해보세요!','','','','','무한의탑','당신의 능력을 시험해보세요!','','','','\r',0);
INSERT INTO `quests` VALUES (99994,991,'','',1,0,0,2,0,0,99994,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,'2014-06-19 08:09:17','No pair',NULL,'무한의탑','당신의 능력을 시험해보세요!','','','','','무한의탑','당신의 능력을 시험해보세요!','','','','\r',0);
INSERT INTO `quests` VALUES (99995,991,'','',1,0,0,3,0,0,99995,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,'2014-06-19 08:09:17','No pair',NULL,'무한의탑','당신의 능력을 시험해보세요!','','','','','무한의탑','당신의 능력을 시험해보세요!','','','','\r',0);
INSERT INTO `quests` VALUES (99996,991,'','',1,0,0,6,0,0,99996,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,'2014-06-19 08:09:34','No pair',NULL,'무한의탑','당신의 능력을 시험해보세요!','','','','','무한의탑','당신의 능력을 시험해보세요!','','','','\r',0);

INSERT INTO `treasure_datas` VALUES (69001,'OwnCard',6,1,1,NULL,NULL,'treasure','OwnCard','OwnCard','Own Card','room','OwnCard','treasure');
INSERT INTO `treasure_datas` VALUES (69002,'OwnCard',6,1,1,NULL,NULL,'treasure','OwnCard','OwnCard','Own Card','room','OwnCard','treasure');
INSERT INTO `treasure_datas` VALUES (69003,'OwnCard',6,1,2,NULL,NULL,'treasure','OwnCard','OwnCard','Own Card','room','OwnCard','treasure');
INSERT INTO `treasure_datas` VALUES (69004,'OwnCard',6,1,2,NULL,NULL,'treasure','OwnCard','OwnCard','Own Card','room','OwnCard','treasure');
INSERT INTO `treasure_datas` VALUES (69005,'OwnCard',6,1,2,NULL,NULL,'treasure','OwnCard','OwnCard','Own Card','room','OwnCard','treasure');
INSERT INTO `treasure_datas` VALUES (69006,'OwnCard',6,1,3,NULL,NULL,'treasure','OwnCard','OwnCard','Own Card','room','OwnCard','treasure');

